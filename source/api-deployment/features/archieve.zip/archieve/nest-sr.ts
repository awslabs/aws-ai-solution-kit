import {
    AuthorizationType, CfnMethod, Cors, Deployment, EndpointType,
    LambdaIntegration, Method, MethodLoggingLevel, RestApi, Stage
} from '@aws-cdk/aws-apigateway';
import { Repository } from "@aws-cdk/aws-ecr";
import { DockerImageCode, DockerImageFunction } from "@aws-cdk/aws-lambda";
import {
    Aws, CfnCondition, CfnOutput, CfnParameter, Construct, Duration, Fn, RemovalPolicy, Stack,
    StackProps, CustomResource, NestedStack, NestedStackProps
} from "@aws-cdk/core";
import * as lambda from '@aws-cdk/aws-lambda';
import * as cr from '@aws-cdk/custom-resources';
import * as iam from '@aws-cdk/aws-iam';
import * as path from 'path';
import { PythonFunction } from "@aws-cdk/aws-lambda-python";
import { ECRDeployment, DockerImageName } from '../../lib/cdk-ecr-deployment/lib';
import { NestedAiFeatureConstruct } from '../feature-construct';

export interface AiFeatureNestedStackProps extends NestedStackProps {
    readonly reatApi: RestApi;
}

export class SRNestedStack extends NestedStack {
    public readonly featureConfig: {};
    constructor(scope: Construct, id: string, api: RestApi, ecrDeployment: ECRDeployment, props: AiFeatureNestedStackProps) {

        super(scope, id, props);
        const featureName = 'sr';
        this.templateOptions.description = `(SO8023-ocr) - AI Solution Kits - SR for China Business License. Template version v1.0.0`;
        // new NestedAiFeatureConstruct(this, 'sr', {
        //     restApi: api,
        //     lambdaEcrDeployment: ecrDeployment,
        //     lambdaDockerImageUrl: 'public.ecr.aws/aws-gcr-solutions/ai-solution-kit-ocr-business-license:1.0.0',
        //     featureName: 'sr',
        //     featureCategory: 'media',
        // });

        const stackRepo = new Repository(this, `ai-solution-kit-sr`, {
            repositoryName: `ai-solution-kit-sr`,
            removalPolicy: RemovalPolicy.DESTROY,
        });
        // if (ecrDeployment != null) {

        const ecrCR = new CustomResource(this, 'deployECRImage', {
            serviceToken: ecrDeployment?.serviceToken,
            resourceType: 'Custom::AISolutionKitECRLambda',
            properties: {
                SrcImage: `docker://public.ecr.aws/aws-gcr-solutions/ai-solution-kit-ocr-business-license:1.0.0`,
                DestImage: `docker://${stackRepo.repositoryUri}`,
                RepositoryName: `${stackRepo.repositoryName}`
            },
        });
        const appFunction = new DockerImageFunction(
            this,
            `${featureName}App`,
            {
                code: DockerImageCode.fromEcr(
                    Repository.fromRepositoryName(this, `${featureName}Lambda`, stackRepo.repositoryName),
                    {
                        tag: 'latest'
                    }
                ),
                timeout: Duration.seconds(15),
                memorySize: 2048,
            }
        );
        appFunction.node.addDependency(ecrCR);
        // const lambdaInt = new LambdaIntegration(appFunction, { proxy: true });
        const aa = RestApi.fromRestApiAttributes(this, 'client-api', {
            restApiId: props.reatApi.restApiId,
            rootResourceId: props.reatApi.root.resourceId,
        });
        // const bb = RestApi.fromRestApiId(this, api.restApiName, api.restApiId);
        const resource = aa.root.addResource(featureName);
        const post = resource.addMethod('POST', new LambdaIntegration(appFunction, { proxy: true }))

    }
}
