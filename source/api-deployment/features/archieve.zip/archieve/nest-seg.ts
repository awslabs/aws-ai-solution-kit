import {
    AuthorizationType, CfnMethod, Cors, Deployment, EndpointType,
    LambdaIntegration, Method, MethodLoggingLevel, RestApi, Stage
} from '@aws-cdk/aws-apigateway';
import { Repository } from "@aws-cdk/aws-ecr";
import { DockerImageCode, DockerImageFunction } from "@aws-cdk/aws-lambda";
import {
    Aws, CfnCondition, CfnOutput, CfnParameter, Construct, Duration, Fn, RemovalPolicy, Stack,
    StackProps, CustomResource, NestedStack, NestedStackProps
} from "@aws-cdk/core";
import * as lambda from '@aws-cdk/aws-lambda';
import * as cr from '@aws-cdk/custom-resources';
import * as iam from '@aws-cdk/aws-iam';
import * as path from 'path';
import { PythonFunction } from "@aws-cdk/aws-lambda-python";

export class SegNestedStack extends NestedStack {

    public readonly featureConfig: {};

    constructor(scope: Construct, id: string, serviceToken: string, props?: NestedStackProps) {

        super(scope, id, props);
        this.templateOptions.description = `(SO8023-sr) - AI Solution Kits - SR for China Business License. Template version v1.0.0`;

        // const featureSR = new CfnParameter(this, "featureOCR", {
        //     default: 'Yes',
        //     type: 'String',
        //     description: 'Install SR feautre?',
        //     allowedValues: ['Yes', 'No']
        // });

        // this.featureConfig = {
        //     'install': featureSR.valueAsString,
        //     'url': '295155050487.dkr.ecr.us-west-2.amazonaws.com/aikits:ocr-lite'
        // }

        const customResource = new CustomResource(this, `apicustomresource`, {
            serviceToken: serviceToken,
            resourceType: "Custom::EfsModelLambda",
            properties: {
                MountPath: 'aaa',
                Objects: 'bbb',
                Features: [
                    {
                        'url': '295155050487.dkr.ecr.us-west-2.amazonaws.com/aikits:ocr-lite',
                        'resource': 'seg'
                    }
                ]
            },
            removalPolicy: RemovalPolicy.DESTROY,
        });

    }
}