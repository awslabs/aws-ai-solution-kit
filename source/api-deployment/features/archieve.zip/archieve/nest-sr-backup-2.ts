import {
    AuthorizationType, CfnMethod, Cors, Deployment, EndpointType,
    LambdaIntegration, Method, MethodLoggingLevel, RestApi, Stage
} from '@aws-cdk/aws-apigateway';
import { Repository } from "@aws-cdk/aws-ecr";
import { DockerImageCode, DockerImageFunction } from "@aws-cdk/aws-lambda";
import {
    Aws, CfnCondition, CfnOutput, CfnParameter, Construct, Duration, Fn, RemovalPolicy, Stack,
    StackProps, CustomResource, NestedStack, NestedStackProps
} from "@aws-cdk/core";
import * as lambda from '@aws-cdk/aws-lambda';
import * as cr from '@aws-cdk/custom-resources';
import * as iam from '@aws-cdk/aws-iam';
import * as path from 'path';
import { PythonFunction } from "@aws-cdk/aws-lambda-python";
import { ECRDeployment, DockerImageName } from '../../lib/cdk-ecr-deployment/lib';

export class SRNestedStack extends NestedStack {

    public readonly featureConfig: {};

    constructor(scope: Construct, id: string, api: RestApi, apiServiceToken: string, deployECRServiceToken: string, props?: NestedStackProps) {

        super(scope, id, props);
        this.templateOptions.description = `(SO8023-sr) - AI Solution Kits - SR for China Business License. Template version v1.0.0`;

        // const sec = new SolutionEcrConstruct(this, "ocrEcr")
        const stackRepo = new Repository(this, 'ai-solution-kit-ocr', {
            repositoryName: 'ai-solution-kit-sr',
            removalPolicy: RemovalPolicy.RETAIN,
        });
        // ocrLicenseImage.node.addDependency(stackRepo)

        //
        const ecrCR = new CustomResource(this, 'deployECRImage', {
            serviceToken: deployECRServiceToken,
            resourceType: 'Custom::AISolutionKitECRLambda',
            properties: {
                SrcImage: `docker://public.ecr.aws/aws-gcr-solutions/ai-solution-kit-ocr-business-license:1.0.0`,
                // SrcCreds: this.props.src.creds,
                DestImage: `docker://${stackRepo.repositoryUri}`,
                // DestCreds: this.props.dest.creds,
            },
        });


        // Source image 295155050487.dkr.ecr.us-west-2.amazonaws.com/ai-solution-kit-ocr:latest does not exist.
        // 295155050487.dkr.ecr.us-west-2.amazonaws.com/ai-solution-kit-ocr:latest
        // const apiCR = new CustomResource(this, `apiLambda`, {
        //     serviceToken: apiServiceToken,
        //     resourceType: "Custom::AISolutionKitAPILambda",
        //     properties: {
        //         MountPath: 'aaa',
        //         Objects: 'bbb',
        //         Features: [
        //             {
        //                 'url': `${stackRepo.repositoryUri}:latest`,
        //                 'resource': 'ocr',
        //                 // 'function': ocrFunction.functionArn
        //             }
        //         ]
        //     },
        //     removalPolicy: RemovalPolicy.DESTROY,
        // });

        // apiCR.node.addDependency(ecrCR);
        // ecrCR.node.addDependency(apiCR);
        /**
          * Lambda Provision
          */
        const srFunction = new DockerImageFunction(
            this,
            'srFunction',
            {
                code: DockerImageCode.fromEcr(
                    Repository.fromRepositoryName(this, 'srLambda', 'ai-solution-kit-sr'),
                    {
                        tag: 'latest'
                    }
                ),
                timeout: Duration.seconds(15),
                memorySize: 10240,
            }
        );
        srFunction.node.addDependency(ecrCR);
        // new apiCR -> ecrCR -> ocrFunction -> post method
        // old new  ecrCR -> apiCR
        const resource = api.root.addResource('sr');
        const post = resource.addMethod('POST',
            new LambdaIntegration(srFunction, { proxy: true }),
            {
                authorizationType: AuthorizationType.NONE,
            }
        )

    }
}
