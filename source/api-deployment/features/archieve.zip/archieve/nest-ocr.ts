import {
    AuthorizationType, CfnMethod, Cors, Deployment, EndpointType,
    LambdaIntegration, Method, MethodLoggingLevel, RestApi, Stage
} from '@aws-cdk/aws-apigateway';
import { Repository } from "@aws-cdk/aws-ecr";
import { DockerImageCode, DockerImageFunction } from "@aws-cdk/aws-lambda";
import {
    Aws, CfnCondition, CfnOutput, CfnParameter, Construct, Duration, Fn, RemovalPolicy, Stack,
    StackProps, CustomResource, NestedStack, NestedStackProps
} from "@aws-cdk/core";
import * as lambda from '@aws-cdk/aws-lambda';
import * as cr from '@aws-cdk/custom-resources';
import * as iam from '@aws-cdk/aws-iam';
import * as path from 'path';
import { PythonFunction } from "@aws-cdk/aws-lambda-python";
import { ECRDeployment, DockerImageName } from '../../../lib/cdk-ecr-deployment/lib';
import { NestedAiFeatureConstruct } from '../../feature-construct';

export class InferOCRNestedStack extends NestedStack {

    constructor(scope: Construct, id: string, api: RestApi, ecrDeployment?: ECRDeployment, props?: NestedStackProps) {

        super(scope, id, props);
        this.templateOptions.description = `(SO8023-ocr) - AI Solution Kits - OCR for China Business License. Template version {version--}`;
        new NestedAiFeatureConstruct(this, 'ocr', {
            restApi: api,
            lambdaEcrDeployment: ecrDeployment,
            lambdaDockerImageUrl: 'public.ecr.aws/aws-gcr-solutions/ai-solution-kit-ocr-business-license:1.0.0',
            featureName: 'ocr',
            featureCategory: 'media',
        });
    }
}
